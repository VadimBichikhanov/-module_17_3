from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete
from slugify import slugify
from backend.db_depends import get_async_db
from typing import Annotated
from models.user import User  # Correct import statement
from schemas.user import CreateUser, UpdateUser
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter(prefix='/user', tags=['user'])

@router.get('/', summary="Get all users", description="Retrieve a list of all users.")
async def all_users(db: Annotated[AsyncSession, Depends(get_async_db)]):
    try:
        users = db.scalars(select(User)).all()
        if not users:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail='There are no users'
            )
        return users
    except Exception as e:
        logger.error(f"Error fetching all users: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.post('/create', summary="Create a new user", description="Create a new user with the provided details.")
async def create_user(db: Annotated[AsyncSession, Depends(get_async_db)], create_user: CreateUser):
    try:
        db.execute(insert(User).values(
            username=create_user.username,
            firstname=create_user.firstname,
            lastname=create_user.lastname,
            age=create_user.age,
            slug=slugify(create_user.firstname)
        ))
        db.commit()
        return {
            'status_code': status.HTTP_201_CREATED,
            'transaction': 'Successful'
        }
    except Exception as e:
        db.rollback()
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.get('/{user_id}', summary="Get user by ID", description="Retrieve a user by their ID.")
async def user_by_id(db: Annotated[AsyncSession, Depends(get_async_db)], user_id: int):
    try:
        user = db.scalar(select(User).where(User.id == user_id))
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail='User not found'
            )
        return user
    except Exception as e:
        logger.error(f"Error fetching user by ID {user_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.put('/update/{user_id}', summary="Update a user", description="Update an existing user by their ID.")
async def update_user(db: Annotated[AsyncSession, Depends(get_async_db)], user_id: int, update_user_model: UpdateUser):
    try:
        user_update = db.scalar(select(User).where(User.id == user_id))
        if user_update is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail='User not found'
            )

        db.execute(update(User).where(User.id == user_id)
                   .values(
                       firstname=update_user_model.firstname,
                       lastname=update_user_model.lastname,
                       age=update_user_model.age,
                       slug=slugify(update_user_model.firstname)
                   ))
        db.commit()
        return {
            'status_code': status.HTTP_200_OK,
            'transaction': 'User update is successful'
        }
    except Exception as e:
        db.rollback()
        logger.error(f"Error updating user {user_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.delete('/delete/{user_id}', summary="Delete a user", description="Delete a user by their ID.")
async def delete_user(db: Annotated[AsyncSession, Depends(get_async_db)], user_id: int):
    try:
        user_delete = db.scalar(select(User).where(User.id == user_id))
        if user_delete is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail='User not found'
            )
        db.execute(delete(User).where(User.id == user_id))
        db.commit()
        return {
            'status_code': status.HTTP_200_OK,
            'transaction': 'User delete is successful'
        }
    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting user {user_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
