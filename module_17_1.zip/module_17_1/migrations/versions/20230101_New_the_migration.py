"""New the migration

Revision ID: 20230101
Revises: 
Create Date: 2023-01-01 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '20230101'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # Add your upgrade operations here
    pass

def downgrade():
    # Add your downgrade operations here
    pass